package com.example.android.foodiego;

import android.view.MenuItem;

public interface HomeObserver {
    void onNavigationItemSelected(MenuItem item);
}
