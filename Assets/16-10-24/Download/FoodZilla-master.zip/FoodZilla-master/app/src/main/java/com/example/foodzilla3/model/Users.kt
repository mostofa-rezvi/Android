package com.example.foodzilla3.model

data class Users(
    var name:String="",
    var email:String="",
    var phone:String="",
    var address:String=""
)
