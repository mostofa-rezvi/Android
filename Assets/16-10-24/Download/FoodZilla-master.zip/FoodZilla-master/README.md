# FoodZilla
Mobile Application Development in Kotlin for android based on food delivery system
