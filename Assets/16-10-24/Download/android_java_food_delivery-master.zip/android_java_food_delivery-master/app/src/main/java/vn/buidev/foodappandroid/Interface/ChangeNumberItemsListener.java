package vn.buidev.foodappandroid.Interface;


public interface ChangeNumberItemsListener  {
    void changed ();


}
