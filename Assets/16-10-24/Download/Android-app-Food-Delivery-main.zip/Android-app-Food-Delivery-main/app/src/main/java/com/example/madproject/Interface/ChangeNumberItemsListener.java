package com.example.madproject.Interface;

public interface ChangeNumberItemsListener {
    void changed();
}
