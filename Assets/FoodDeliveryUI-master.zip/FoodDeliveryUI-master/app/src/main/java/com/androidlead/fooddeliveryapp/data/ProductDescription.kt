package com.androidlead.fooddeliveryapp.data

val ProductDescriptionData = "Introducing Mr. Cheezy: a burger lover’s dream!\n" +
        "\n" +
        "Sink your teeth into a succulent beef patty, smothered in a rich, melting blend of cheddar, Swiss, and American cheeses. Crispy bacon adds a satisfying crunch, while caramelized onions bring a touch of sweetness.\n" +
        "\n" +
        "Drizzled with zesty BBQ sauce and tucked inside a perfectly toasted brioche bun, Mr. Cheezy is pure, cheesy bliss in every bite."